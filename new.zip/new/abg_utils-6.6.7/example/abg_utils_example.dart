
void main() {
  print('example');
}
